"""
Mode 1 verification: Hardware-Attestation header (CMS SignedData).

RFC: draft-drake-email-hardware-attestation-03, Section 5

Verification steps:
  1. Parse the header parameters (v, typ, alg, h, bh, ts, chain)
  2. Decode the CMS SignedData from the chain parameter
  3. Recompute the 72-byte attestation-input (h-hash || bh-raw || ts-bytes)
  4. Verify the CMS signature using the leaf certificate's public key
  5. Validate the certificate chain
"""

from __future__ import annotations

import base64
import email.header
import hashlib
import re
import struct
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, rsa, padding

from .parse import ParsedHardwareAttestationHeader, parse_hardware_attestation_header


_MINIMUM_HEADERS_FOR_RFC_MESSAGE_BINDING = [
  "from", "to", "subject", "date", "message-id",
]

_DEFAULT_MAX_TIMESTAMP_SKEW_SECONDS = 300


@dataclass
class VerificationResult:
  """Result of verifying a Hardware-Attestation header."""
  is_valid: bool = False
  trust_tier: str = ""
  typ: str = ""
  alg: str = ""
  timestamp_unix: int = 0
  agent_identity_urn: Optional[str] = None
  leaf_certificate_subject: str = ""
  certificate_chain_length: int = 0
  failure_reason: str = ""
  failure_reasons: List[str] = field(default_factory=list)


_ACCEPTED_CMS_ALGORITHMS = {"RS256", "ES256", "PS256"}


def verify_hardware_attestation(
  header_value: str,
  email_headers: Dict[str, str],
  body: bytes,
  ordered_header_pairs: Optional[List[tuple]] = None,
  max_timestamp_skew_seconds: int = _DEFAULT_MAX_TIMESTAMP_SKEW_SECONDS,
  trusted_root_certificates: Optional[List[x509.Certificate]] = None,
  allow_self_signed: bool = False,
  reference_time_unix: Optional[int] = None,
  allow_eddsa: bool = False,
) -> VerificationResult:
  """Verify a Mode 1 Hardware-Attestation header.

  Args:
    header_value: The raw Hardware-Attestation header value string.
    email_headers: Dict of email header name -> value (must include required headers).
    body: Raw email body bytes.
    max_timestamp_skew_seconds: Maximum allowed time drift (default 300s / 5 minutes).
    trusted_root_certificates: Optional list of trusted root CA certs for chain validation.
    allow_self_signed: If True, accept self-signed leaf certificates (testing only).
    reference_time_unix: Unix timestamp to use for time checks (default: now).

  Returns:
    VerificationResult with is_valid=True if all checks pass.
  """
  result = VerificationResult()
  failure_reasons: List[str] = []

  parsed = parse_hardware_attestation_header(header_value)
  result.typ = parsed.typ
  result.trust_tier = parsed.trust_tier
  result.alg = parsed.alg
  result.timestamp_unix = parsed.ts
  result.agent_identity_urn = parsed.aid

  if parsed.version != 1:
    failure_reasons.append(f"Unsupported version: v={parsed.version} (expected v=1)")

  if not parsed.typ:
    failure_reasons.append("Missing typ parameter")

  if not parsed.alg:
    failure_reasons.append("Missing alg parameter")
  elif parsed.alg not in _ACCEPTED_CMS_ALGORITHMS:
    if parsed.alg == "EdDSA" and not allow_eddsa:
      failure_reasons.append(
        "EdDSA is not in the Version 1 CMS algorithm table (use --allow-eddsa to accept)"
      )
    elif parsed.alg != "EdDSA":
      failure_reasons.append(f"Unsupported algorithm: {parsed.alg}")

  if not parsed.chain_base64:
    failure_reasons.append("Missing or empty chain parameter")

  if not parsed.bh:
    failure_reasons.append("Missing bh parameter")

  if parsed.ts == 0:
    failure_reasons.append("Missing or invalid ts parameter")

  _REQUIRED_SIGNED_HEADERS = {"from", "to", "subject", "date", "message-id"}
  signed_names_lower = {n.strip().lower() for n in parsed.signed_header_names}
  missing_required_headers = _REQUIRED_SIGNED_HEADERS - signed_names_lower
  if missing_required_headers:
    failure_reasons.append(
      f"h= tag missing required headers: {', '.join(sorted(missing_required_headers))}"
    )

  if failure_reasons:
    result.failure_reasons = failure_reasons
    result.failure_reason = failure_reasons[0]
    return result

  if reference_time_unix is None:
    reference_time_unix = int(time.time())

  timestamp_age_seconds = abs(reference_time_unix - parsed.ts)
  if timestamp_age_seconds > max_timestamp_skew_seconds:
    failure_reasons.append(
      f"Timestamp too far from current time: {timestamp_age_seconds}s drift "
      f"(max allowed: {max_timestamp_skew_seconds}s)"
    )

  try:
    chain_der_bytes = base64.b64decode(parsed.chain_base64)
  except Exception as decode_error:
    failure_reasons.append(f"Could not base64-decode chain parameter: {decode_error}")
    result.failure_reasons = failure_reasons
    result.failure_reason = failure_reasons[0]
    return result

  cms_digest_algorithm_validation_error = _validate_cms_digest_algorithm_is_sha256(chain_der_bytes)
  if cms_digest_algorithm_validation_error:
    failure_reasons.append(cms_digest_algorithm_validation_error)

  extracted_certificates = _extract_certificates_from_cms_signed_data(chain_der_bytes)
  if not extracted_certificates:
    failure_reasons.append("No certificates found in CMS SignedData")
    result.failure_reasons = failure_reasons
    result.failure_reason = failure_reasons[0]
    return result

  result.certificate_chain_length = len(extracted_certificates)

  extracted_signature_bytes = _extract_signature_from_cms_signed_data(chain_der_bytes)
  if extracted_signature_bytes is None:
    failure_reasons.append("Could not extract signature from CMS SignedData")
    result.failure_reasons = failure_reasons
    result.failure_reason = failure_reasons[0]
    return result

  header_value_without_chain_for_self_reference = _reconstruct_header_template_without_chain(parsed)

  attestation_input_72_bytes = _compute_attestation_input(
    email_headers=email_headers,
    body_bytes=body,
    attestation_timestamp_unix=parsed.ts,
    header_value_without_chain=header_value_without_chain_for_self_reference,
    signed_header_names_from_h_tag=parsed.signed_header_names,
    ordered_header_pairs=ordered_header_pairs,
  )

  leaf_certificate = None
  for candidate_certificate in extracted_certificates:
    verification_error = _verify_signature_against_certificate(
      leaf_certificate=candidate_certificate,
      signature_bytes=extracted_signature_bytes,
      attestation_input_72_bytes=attestation_input_72_bytes,
      algorithm_name=parsed.alg,
    )
    if verification_error is None:
      leaf_certificate = candidate_certificate
      break
  if leaf_certificate is None:
    failure_reasons.append(
      "Signature verification failed: no certificate in the CMS bundle "
      "has a key that verifies the signature"
    )

  if leaf_certificate is not None:
    try:
      subject_common_names = leaf_certificate.subject.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)
      if subject_common_names:
        result.leaf_certificate_subject = subject_common_names[0].value
      else:
        result.leaf_certificate_subject = str(leaf_certificate.subject)
    except Exception:
      result.leaf_certificate_subject = "(could not extract subject)"

  try:
    received_bh_bytes = _base64url_decode(parsed.bh)
  except Exception as bh_decode_error:
    failure_reasons.append(f"Could not base64url-decode bh parameter: {bh_decode_error}")
    received_bh_bytes = None
  if received_bh_bytes is not None:
    canonicalised_body = _canonicalise_body_using_dkim_simple(body)
    recomputed_bh = hashlib.sha256(canonicalised_body).digest()
    if received_bh_bytes != recomputed_bh:
      failure_reasons.append("Body hash (bh) does not match recomputed hash")

  if trusted_root_certificates:
    chain_validation_error = _validate_certificate_chain(
      extracted_certificates, trusted_root_certificates,
    )
    if chain_validation_error:
      failure_reasons.append(f"Certificate chain validation failed: {chain_validation_error}")
  elif not allow_self_signed:
    failure_reasons.append(
      "No trusted root certificates provided and allow_self_signed is False. "
      "Provide trusted_root_certificates or set allow_self_signed=True for testing."
    )

  if parsed.aid and not parsed.bind:
    failure_reasons.append(
      "aid is present but bind is absent (sender MUST NOT place aid without Registrar binding)"
    )
  elif parsed.bind and not parsed.aid:
    failure_reasons.append(
      "bind is present but aid is absent (aid and bind must both appear or both be absent)"
    )

  if parsed.bind and parsed.aid and leaf_certificate is not None and not failure_reasons:
    bind_verification_errors = _verify_registrar_binding_jws(
      bind_compact_jws=parsed.bind,
      expected_aid=parsed.aid,
      expected_typ=parsed.typ,
      signer_certificate=leaf_certificate,
      reference_time_unix=reference_time_unix if reference_time_unix else int(time.time()),
      max_timestamp_skew_seconds=max_timestamp_skew_seconds,
    )
    failure_reasons.extend(bind_verification_errors)

  if failure_reasons:
    result.failure_reasons = failure_reasons
    result.failure_reason = failure_reasons[0]
    return result

  result.is_valid = True
  return result


_TYP_TO_EXPECTED_TRUST_TIER = {
  "TPM": "sovereign",
  "PIV": "portable",
  "ENC": "enclave",
  "VRT": "virtual",
  "SFT": "declared",
}


def _verify_registrar_binding_jws(
  bind_compact_jws: str,
  expected_aid: str,
  expected_typ: str,
  signer_certificate: x509.Certificate,
  reference_time_unix: int,
  max_timestamp_skew_seconds: int = 300,
) -> List[str]:
  """Verify a Registrar Binding JWS per RFC Section 5.4.

  Returns a list of failure reasons (empty = success).
  """
  import json
  errors: List[str] = []

  parts = bind_compact_jws.split(".")
  if len(parts) != 3:
    return ["bind JWS is not a valid compact JWS (expected 3 dot-separated parts)"]

  try:
    header_json = _base64url_decode(parts[0]).decode("utf-8")
    payload_json = _base64url_decode(parts[1]).decode("utf-8")
    signature_bytes = _base64url_decode(parts[2])
  except Exception as decode_error:
    return [f"bind JWS base64url decode failed: {decode_error}"]

  try:
    header = json.loads(header_json)
  except json.JSONDecodeError:
    return ["bind JWS header is not valid JSON"]

  try:
    payload = json.loads(payload_json)
  except json.JSONDecodeError:
    return ["bind JWS payload is not valid JSON"]

  bind_typ = header.get("typ", "")
  if bind_typ != "airs-email-binding+jwt":
    errors.append(
      f"bind JWS typ must be 'airs-email-binding+jwt' (got {bind_typ!r})"
    )

  bind_alg = header.get("alg", "")
  if not bind_alg or bind_alg in ("none", "HS256", "HS384", "HS512"):
    errors.append(f"bind JWS alg is invalid or symmetric: {bind_alg!r}")

  bind_iss = payload.get("iss", "")
  if not bind_iss:
    errors.append("bind JWS missing iss claim")

  bind_sub = payload.get("sub", "")
  if bind_sub != expected_aid:
    errors.append(
      f"bind JWS sub {bind_sub!r} does not match header aid {expected_aid!r}"
    )

  bind_iat = payload.get("iat")
  bind_exp = payload.get("exp")
  if bind_iat is None:
    errors.append("bind JWS missing iat claim")
  else:
    if int(bind_iat) > reference_time_unix + max_timestamp_skew_seconds:
      errors.append(f"bind JWS iat is in the future: {bind_iat}")

  if bind_exp is None:
    errors.append("bind JWS missing exp claim")
  else:
    if int(bind_exp) < reference_time_unix - max_timestamp_skew_seconds:
      errors.append(f"bind JWS has expired: exp={bind_exp}, now={reference_time_unix}")

  if bind_iat is not None and bind_exp is not None:
    if int(bind_exp) <= int(bind_iat):
      errors.append("bind JWS exp must be later than iat")

  cnf = payload.get("cnf")
  if not isinstance(cnf, dict) or "jwk" not in cnf:
    errors.append("bind JWS missing cnf.jwk claim")
  else:
    bind_jwk = cnf["jwk"]
    if any(k in bind_jwk for k in ("d", "p", "q", "dp", "dq", "qi", "k")):
      errors.append("bind JWS cnf.jwk contains private key parameters")
    else:
      signer_jwk_thumbprint = _compute_jwk_thumbprint_from_certificate(signer_certificate)
      bind_jwk_thumbprint = _compute_jwk_thumbprint_from_jwk_dict(bind_jwk)
      if signer_jwk_thumbprint and bind_jwk_thumbprint:
        if signer_jwk_thumbprint != bind_jwk_thumbprint:
          errors.append(
            "bind JWS cnf.jwk thumbprint does not match CMS signer public key"
          )
      elif not signer_jwk_thumbprint:
        errors.append("Could not compute JWK thumbprint from CMS signer certificate")

  aid_claim = payload.get("aid")
  if isinstance(aid_claim, dict):
    bind_trust_tier = aid_claim.get("trust_tier", "")
    expected_tier_from_typ = _TYP_TO_EXPECTED_TRUST_TIER.get(expected_typ, "")
    if expected_tier_from_typ and bind_trust_tier != expected_tier_from_typ:
      errors.append(
        f"bind JWS aid.trust_tier {bind_trust_tier!r} does not match "
        f"expected tier for typ={expected_typ!r} ({expected_tier_from_typ!r})"
      )

  if not errors:
    from .issuer_key_discovery import discover_issuer_public_key
    from urllib.parse import urlparse
    issuer_domain = urlparse(bind_iss).hostname if bind_iss.startswith("http") else bind_iss
    bind_kid = header.get("kid")
    issuer_key = discover_issuer_public_key(issuer_domain, kid=bind_kid) if issuer_domain else None
    if issuer_key is None:
      errors.append(
        f"Could not discover issuer public key for bind JWS issuer {bind_iss!r}"
      )
    else:
      from cryptography.exceptions import InvalidSignature as InvSig
      signing_input = f"{parts[0]}.{parts[1]}".encode("ascii")
      try:
        if bind_alg == "ES256":
          sig_for_verify = signature_bytes
          if len(sig_for_verify) == 64:
            from .mode2 import _raw_rs_to_der
            sig_for_verify = _raw_rs_to_der(sig_for_verify)
          issuer_key.verify(sig_for_verify, signing_input, ec.ECDSA(hashes.SHA256()))
        else:
          errors.append(f"Unsupported bind JWS algorithm for verification: {bind_alg}")
      except InvSig:
        errors.append("bind JWS signature verification failed")
      except Exception as sig_error:
        errors.append(f"bind JWS signature verification error: {sig_error}")

  return errors


def _compute_jwk_thumbprint_from_certificate(cert: x509.Certificate) -> Optional[str]:
  """Compute RFC 7638 JWK thumbprint from a certificate's public key."""
  pub = cert.public_key()
  return _compute_jwk_thumbprint_from_public_key(pub)


def _compute_jwk_thumbprint_from_public_key(pub) -> Optional[str]:
  """Compute RFC 7638 JWK thumbprint from a public key object."""
  import json

  try:
    if isinstance(pub, ec.EllipticCurvePublicKey):
      numbers = pub.public_numbers()
      curve_name = pub.curve.name
      crv = {"secp256r1": "P-256", "secp384r1": "P-384", "secp521r1": "P-521"}.get(curve_name)
      if not crv:
        return None
      x_bytes = numbers.x.to_bytes((pub.key_size + 7) // 8, "big")
      y_bytes = numbers.y.to_bytes((pub.key_size + 7) // 8, "big")
      x_b64 = base64.urlsafe_b64encode(x_bytes).rstrip(b"=").decode("ascii")
      y_b64 = base64.urlsafe_b64encode(y_bytes).rstrip(b"=").decode("ascii")
      thumbprint_input = json.dumps(
        {"crv": crv, "kty": "EC", "x": x_b64, "y": y_b64},
        separators=(",", ":"), sort_keys=True,
      )
    elif isinstance(pub, rsa.RSAPublicKey):
      numbers = pub.public_numbers()
      e_bytes = numbers.e.to_bytes((numbers.e.bit_length() + 7) // 8, "big")
      n_bytes = numbers.n.to_bytes((numbers.n.bit_length() + 7) // 8, "big")
      e_b64 = base64.urlsafe_b64encode(e_bytes).rstrip(b"=").decode("ascii")
      n_b64 = base64.urlsafe_b64encode(n_bytes).rstrip(b"=").decode("ascii")
      thumbprint_input = json.dumps(
        {"e": e_b64, "kty": "RSA", "n": n_b64},
        separators=(",", ":"), sort_keys=True,
      )
    else:
      return None
    return base64.urlsafe_b64encode(
      hashlib.sha256(thumbprint_input.encode("ascii")).digest()
    ).rstrip(b"=").decode("ascii")
  except Exception:
    return None


def _compute_jwk_thumbprint_from_jwk_dict(jwk: dict) -> Optional[str]:
  """Compute RFC 7638 JWK thumbprint from a JWK dictionary."""
  import json

  try:
    kty = jwk.get("kty", "")
    if kty == "EC":
      thumbprint_input = json.dumps(
        {"crv": jwk["crv"], "kty": "EC", "x": jwk["x"], "y": jwk["y"]},
        separators=(",", ":"), sort_keys=True,
      )
    elif kty == "RSA":
      thumbprint_input = json.dumps(
        {"e": jwk["e"], "kty": "RSA", "n": jwk["n"]},
        separators=(",", ":"), sort_keys=True,
      )
    else:
      return None
    return base64.urlsafe_b64encode(
      hashlib.sha256(thumbprint_input.encode("ascii")).digest()
    ).rstrip(b"=").decode("ascii")
  except (KeyError, Exception):
    return None


def _reconstruct_header_template_without_chain(parsed: ParsedHardwareAttestationHeader) -> str:
  """Reconstruct the self-canonical header value per RFC Section 5.2.

  Per spec: field name lowercase, params in ABNF order, exactly one SP
  after the colon and each semicolon, chain= empty, all other params
  (including FWS-free bind) remain present.
  """
  signed_header_names_str = ":".join(parsed.signed_header_names)
  template = (
    f"v={parsed.version}; typ={parsed.typ}; alg={parsed.alg}; "
    f"h={signed_header_names_str}; bh={parsed.bh}; ts={parsed.ts}; "
    f"chain="
  )
  if parsed.aid:
    template += f"; aid={parsed.aid}"
  if parsed.bind:
    template += f"; bind={parsed.bind}"
  return template


def _select_headers_bottom_up_per_dkim(
  header_names_from_h_tag: List[str],
  message_headers: List[tuple],
) -> List[Optional[tuple]]:
  """Select header instances per DKIM RFC 6376 Section 3.7 bottom-up rule.

  For each name in header_names_from_h_tag (left to right), scan
  message_headers from bottom to top and consume the bottommost unused
  instance. If no unused instance remains, return None for that slot
  (absent header -- contributes zero bytes to the hash).
  """
  consumed_indices: set = set()
  selected: List[Optional[tuple]] = []
  for requested_name in header_names_from_h_tag:
    target = requested_name.strip().lower()
    found_index = -1
    for i in range(len(message_headers) - 1, -1, -1):
      if i in consumed_indices:
        continue
      if message_headers[i][0].strip().lower() == target:
        found_index = i
        break
    if found_index >= 0:
      consumed_indices.add(found_index)
      selected.append(message_headers[found_index])
    else:
      selected.append(None)
  return selected


def _compute_attestation_input(
  email_headers: Dict[str, str],
  body_bytes: bytes,
  attestation_timestamp_unix: int,
  header_value_without_chain: str,
  signed_header_names_from_h_tag: Optional[List[str]] = None,
  ordered_header_pairs: Optional[List[tuple]] = None,
) -> bytes:
  """Compute the 72-byte attestation-input for Mode 1 (RFC Section 5.2).

  attestation-input = h-hash || bh-raw || ts-bytes   (exactly 72 octets)

  Per RFC: "The externally supplied detached content is the exact 72-octet
  attestation-input; implementations MUST NOT pre-hash that value and then
  present the digest to CMS as though it were the content."
  """
  canonicalised_header_bytes = _canonicalise_headers_for_direct_attestation(
    email_headers, header_value_without_chain,
    signed_header_names_from_h_tag=signed_header_names_from_h_tag,
    ordered_header_pairs=ordered_header_pairs,
  )
  h_hash = hashlib.sha256(canonicalised_header_bytes).digest()

  canonicalised_body = _canonicalise_body_using_dkim_simple(body_bytes)
  bh_raw = hashlib.sha256(canonicalised_body).digest()

  ts_bytes = struct.pack(">Q", attestation_timestamp_unix)

  return h_hash + bh_raw + ts_bytes


def _canonicalise_headers_for_direct_attestation(
  email_headers: Dict[str, str],
  header_value_without_chain: str,
  signed_header_names_from_h_tag: Optional[List[str]] = None,
  ordered_header_pairs: Optional[List[tuple]] = None,
) -> bytes:
  """Canonicalise headers for Mode 1 attestation digest, per RFC Section 5.2.

  Uses DKIM bottom-up header selection when ordered_header_pairs and
  signed_header_names_from_h_tag are provided. Absent headers in h=
  contribute zero bytes per RFC 6376 Section 3.7.
  """
  if ordered_header_pairs is not None and signed_header_names_from_h_tag is not None:
    selected = _select_headers_bottom_up_per_dkim(
      signed_header_names_from_h_tag, ordered_header_pairs,
    )
    lines: List[str] = []
    for entry in selected:
      if entry is None:
        continue
      canon_name = entry[0].strip().lower()
      canon_value = _dkim_relaxed_header_value(entry[1])
      lines.append(f"{canon_name}:{canon_value}\r\n")
    lines.append(f"hardware-attestation: {header_value_without_chain}")
    return "".join(lines).encode("utf-8")

  lowered = {k.strip().lower(): v for k, v in email_headers.items()}
  lines = []
  for required_name in _MINIMUM_HEADERS_FOR_RFC_MESSAGE_BINDING:
    if required_name not in lowered:
      continue
    canon_name = required_name.strip().lower()
    canon_value = _dkim_relaxed_header_value(lowered[required_name])
    lines.append(f"{canon_name}:{canon_value}\r\n")

  for extra_name in sorted(lowered.keys()):
    if extra_name in _MINIMUM_HEADERS_FOR_RFC_MESSAGE_BINDING:
      continue
    if extra_name in ("hardware-attestation", "hardware-trust-proof"):
      continue
    canon_name = extra_name.strip().lower()
    canon_value = _dkim_relaxed_header_value(lowered[extra_name])
    lines.append(f"{canon_name}:{canon_value}\r\n")

  lines.append(f"hardware-attestation: {header_value_without_chain}")
  return "".join(lines).encode("utf-8")


def _decode_rfc2047_encoded_words_to_unicode(raw_header_value: str) -> str:
  """Decode RFC 2047 encoded-words to plain Unicode before canonicalization."""
  try:
    decoded_parts = email.header.decode_header(raw_header_value)
    return str(email.header.make_header(decoded_parts))
  except Exception:
    return raw_header_value


def _dkim_relaxed_header_value(raw_value: str) -> str:
  """RFC 6376 Section 3.4.2 relaxed header canonicalization (value part).

  Pre-step: Decode RFC 2047 encoded-words to Unicode, then normalize.
  """
  decoded = _decode_rfc2047_encoded_words_to_unicode(raw_value)
  normalized = decoded.replace("\r\n", "\n").replace("\n", "\r\n")
  unfolded = re.sub(r"\r\n[ \t]", " ", normalized)
  compressed = re.sub(r"[ \t]+", " ", unfolded)
  return compressed.strip()


def _canonicalise_body_using_dkim_simple(body_bytes: bytes) -> bytes:
  """RFC 6376 Section 3.4.3 simple body canonicalization.

  Normalizes bare LF to CRLF first (emails stored on disk often lose CR).
  """
  if not body_bytes:
    return b"\r\n"
  body_bytes = body_bytes.replace(b"\r\n", b"\n").replace(b"\r", b"\n").replace(b"\n", b"\r\n")
  while body_bytes.endswith(b"\r\n\r\n"):
    body_bytes = body_bytes[:-2]
  if not body_bytes.endswith(b"\r\n"):
    body_bytes = body_bytes + b"\r\n"
  return body_bytes


def _base64url_decode(encoded_string: str) -> bytes:
  """Decode base64url (no padding) to bytes."""
  padded = encoded_string + "=" * ((4 - len(encoded_string) % 4) % 4)
  return base64.urlsafe_b64decode(padded)


def _extract_certificates_from_cms_signed_data(cms_der_bytes: bytes) -> List[x509.Certificate]:
  """Extract certificates from a CMS SignedData DER structure.

  Walks the ASN.1 structure to find the [0] IMPLICIT SET OF Certificate
  within the SignedData SEQUENCE.
  """
  certificates: List[x509.Certificate] = []
  try:
    offset = 0
    tag, length, value_offset = _asn1_read_tag_length(cms_der_bytes, offset)
    content_info_bytes = cms_der_bytes[value_offset:value_offset + length]

    inner_offset = 0
    oid_tag, oid_len, oid_val_offset = _asn1_read_tag_length(content_info_bytes, inner_offset)
    inner_offset = oid_val_offset + oid_len

    if inner_offset >= len(content_info_bytes):
      return certificates

    explicit_tag, explicit_len, explicit_val_offset = _asn1_read_tag_length(content_info_bytes, inner_offset)
    signed_data_bytes = content_info_bytes[explicit_val_offset:explicit_val_offset + explicit_len]

    sd_offset = 0
    sd_tag, sd_len, sd_val_offset = _asn1_read_tag_length(signed_data_bytes, sd_offset)
    sd_content = signed_data_bytes[sd_val_offset:sd_val_offset + sd_len]

    pos = 0
    while pos < len(sd_content):
      elem_tag, elem_len, elem_val_offset = _asn1_read_tag_length(sd_content, pos)
      elem_end = elem_val_offset + elem_len

      if elem_tag == 0xA0:
        certs_content = sd_content[elem_val_offset:elem_end]
        cert_pos = 0
        while cert_pos < len(certs_content):
          cert_tag, cert_len, cert_val_offset = _asn1_read_tag_length(certs_content, cert_pos)
          cert_der = certs_content[cert_pos:cert_val_offset + cert_len]
          try:
            cert = x509.load_der_x509_certificate(cert_der)
            certificates.append(cert)
          except Exception:
            pass
          cert_pos = cert_val_offset + cert_len
        break

      pos = elem_end

  except Exception:
    pass

  return certificates


def _extract_signature_from_cms_signed_data(cms_der_bytes: bytes) -> Optional[bytes]:
  """Extract the signature bytes from the SignerInfo in a CMS SignedData."""
  try:
    offset = 0
    tag, length, value_offset = _asn1_read_tag_length(cms_der_bytes, offset)
    content_info_bytes = cms_der_bytes[value_offset:value_offset + length]

    inner_offset = 0
    oid_tag, oid_len, oid_val_offset = _asn1_read_tag_length(content_info_bytes, inner_offset)
    inner_offset = oid_val_offset + oid_len

    explicit_tag, explicit_len, explicit_val_offset = _asn1_read_tag_length(content_info_bytes, inner_offset)
    signed_data_bytes = content_info_bytes[explicit_val_offset:explicit_val_offset + explicit_len]

    sd_tag, sd_len, sd_val_offset = _asn1_read_tag_length(signed_data_bytes, 0)
    sd_content = signed_data_bytes[sd_val_offset:sd_val_offset + sd_len]

    last_set_content = None
    pos = 0
    while pos < len(sd_content):
      elem_tag, elem_len, elem_val_offset = _asn1_read_tag_length(sd_content, pos)
      elem_end = elem_val_offset + elem_len
      if elem_tag == 0x31:
        last_set_content = sd_content[elem_val_offset:elem_end]
      pos = elem_end

    if last_set_content is None:
      return None

    signer_info_tag, si_len, si_val_offset = _asn1_read_tag_length(last_set_content, 0)
    signer_info_content = last_set_content[si_val_offset:si_val_offset + si_len]

    last_octet_string_value = None
    si_pos = 0
    while si_pos < len(signer_info_content):
      si_tag, si_elem_len, si_elem_val_offset = _asn1_read_tag_length(signer_info_content, si_pos)
      si_elem_end = si_elem_val_offset + si_elem_len
      if si_tag == 0x04:
        last_octet_string_value = signer_info_content[si_elem_val_offset:si_elem_end]
      si_pos = si_elem_end

    return last_octet_string_value

  except Exception:
    return None


def _asn1_read_tag_length(data: bytes, offset: int) -> tuple:
  """Read an ASN.1 tag and length at the given offset.

  Returns (tag, length, value_offset).
  """
  if offset >= len(data):
    raise ValueError(f"ASN.1 read past end of data at offset {offset}")

  tag = data[offset]
  offset += 1

  if offset >= len(data):
    raise ValueError("ASN.1 truncated after tag")

  first_length_byte = data[offset]
  offset += 1

  if first_length_byte < 0x80:
    return (tag, first_length_byte, offset)

  num_length_bytes = first_length_byte & 0x7F
  if num_length_bytes == 0:
    raise ValueError("ASN.1 indefinite length not supported")

  length_value = 0
  for _ in range(num_length_bytes):
    if offset >= len(data):
      raise ValueError("ASN.1 truncated in length")
    length_value = (length_value << 8) | data[offset]
    offset += 1

  return (tag, length_value, offset)


_SHA256_OID_BYTES = bytes([0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01])


def _validate_cms_digest_algorithm_is_sha256(cms_der_bytes: bytes) -> Optional[str]:
  """Check that the CMS SignedData digestAlgorithms set includes SHA-256.

  Per RFC Section 5.5: SignedData digestAlgorithms set MUST identify SHA-256.
  Returns None on success, or an error string.
  """
  try:
    offset = 0
    _tag, length, value_offset = _asn1_read_tag_length(cms_der_bytes, offset)
    content_info_bytes = cms_der_bytes[value_offset:value_offset + length]

    inner_offset = 0
    _oid_tag, oid_len, oid_val_offset = _asn1_read_tag_length(content_info_bytes, inner_offset)
    inner_offset = oid_val_offset + oid_len

    _explicit_tag, explicit_len, explicit_val_offset = _asn1_read_tag_length(content_info_bytes, inner_offset)
    signed_data_bytes = content_info_bytes[explicit_val_offset:explicit_val_offset + explicit_len]

    _sd_tag, _sd_len, sd_val_offset = _asn1_read_tag_length(signed_data_bytes, 0)
    sd_content = signed_data_bytes[sd_val_offset:sd_val_offset + _sd_len]

    pos = 0
    _version_tag, version_len, version_val_offset = _asn1_read_tag_length(sd_content, pos)
    pos = version_val_offset + version_len

    if pos < len(sd_content):
      digest_set_tag, digest_set_len, digest_set_val_offset = _asn1_read_tag_length(sd_content, pos)
      if digest_set_tag == 0x31:
        digest_algorithms_bytes = sd_content[digest_set_val_offset:digest_set_val_offset + digest_set_len]
        if _SHA256_OID_BYTES in digest_algorithms_bytes:
          return None
        return "CMS digestAlgorithms set does not include SHA-256 (required by RFC Section 5.5)"
  except Exception:
    pass
  return None


def _validate_certificate_chain(
  chain: List[x509.Certificate],
  trusted_roots: List[x509.Certificate],
) -> Optional[str]:
  """Validate cert chain: signatures, validity periods, basic constraints, trust anchor.

  Returns None on success, or an error string on failure.
  """
  if not chain:
    return "Certificate chain is empty"

  import datetime

  trusted_root_fingerprints = set()
  for root in trusted_roots:
    try:
      pub_der = root.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
      )
      trusted_root_fingerprints.add(pub_der)
    except Exception:
      pass

  now = datetime.datetime.now(datetime.timezone.utc)

  for i, cert in enumerate(chain):
    if cert.not_valid_before_utc > now:
      return f"Certificate at position {i} is not yet valid (notBefore={cert.not_valid_before_utc})"
    if cert.not_valid_after_utc < now:
      return f"Certificate at position {i} has expired (notAfter={cert.not_valid_after_utc})"

  for i in range(1, len(chain)):
    intermediate_cert = chain[i]
    try:
      basic_constraints = intermediate_cert.extensions.get_extension_for_class(
        x509.BasicConstraints
      )
      if not basic_constraints.value.ca:
        return f"Certificate at position {i} has basicConstraints CA:FALSE (must be CA)"
    except x509.ExtensionNotFound:
      pass

  leaf = chain[0]
  try:
    key_usage = leaf.extensions.get_extension_for_class(x509.KeyUsage)
    if not key_usage.value.digital_signature:
      return f"Leaf certificate lacks digitalSignature keyUsage"
  except x509.ExtensionNotFound:
    pass

  for i in range(len(chain) - 1):
    child = chain[i]
    parent = chain[i + 1]
    parent_key = parent.public_key()

    try:
      if isinstance(parent_key, rsa.RSAPublicKey):
        parent_key.verify(
          child.signature, child.tbs_certificate_bytes,
          padding.PKCS1v15(), child.signature_hash_algorithm,
        )
      elif isinstance(parent_key, ec.EllipticCurvePublicKey):
        parent_key.verify(
          child.signature, child.tbs_certificate_bytes,
          ec.ECDSA(child.signature_hash_algorithm),
        )
      else:
        return f"Unsupported key type at position {i+1}: {type(parent_key).__name__}"
    except InvalidSignature:
      return f"Certificate at position {i} is not signed by certificate at position {i+1}"
    except Exception as chain_error:
      return f"Error verifying cert at position {i}: {chain_error}"

  root_cert = chain[-1]
  root_pub_der = root_cert.public_key().public_bytes(
    serialization.Encoding.DER,
    serialization.PublicFormat.SubjectPublicKeyInfo,
  )
  if root_pub_der not in trusted_root_fingerprints:
    return f"Chain root '{root_cert.subject}' is not in the set of trusted roots"

  return None


def _verify_signature_against_certificate(
  leaf_certificate: x509.Certificate,
  signature_bytes: bytes,
  attestation_input_72_bytes: bytes,
  algorithm_name: str,
) -> Optional[str]:
  """Verify a CMS signature using the leaf certificate's public key.

  Returns None on success, or an error message string on failure.

  All signers (TPM, PIV, enclave, software) receive the 72-byte
  attestation-input and hash it internally via their sign() method
  (Go crypto.Signer for hardware, cryptography library for software).
  Verification therefore always uses SHA256() over the same 72-byte
  input -- no per-hardware-type branching is needed.
  """
  public_key = leaf_certificate.public_key()

  try:
    if algorithm_name == "ES256":
      if not isinstance(public_key, ec.EllipticCurvePublicKey):
        return f"Certificate has {type(public_key).__name__}, expected EC for ES256"
      public_key.verify(signature_bytes, attestation_input_72_bytes, ec.ECDSA(hashes.SHA256()))
    elif algorithm_name == "RS256":
      if not isinstance(public_key, rsa.RSAPublicKey):
        return f"Certificate has {type(public_key).__name__}, expected RSA for RS256"
      public_key.verify(
        signature_bytes, attestation_input_72_bytes,
        padding.PKCS1v15(), hashes.SHA256(),
      )
    elif algorithm_name == "PS256":
      if not isinstance(public_key, rsa.RSAPublicKey):
        return f"Certificate has {type(public_key).__name__}, expected RSA for PS256"
      public_key.verify(
        signature_bytes, attestation_input_72_bytes,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.AUTO),
        hashes.SHA256(),
      )
    elif algorithm_name == "EdDSA":
      if not isinstance(public_key, ed25519.Ed25519PublicKey):
        return f"Certificate has {type(public_key).__name__}, expected Ed25519 for EdDSA"
      public_key.verify(signature_bytes, attestation_input_72_bytes)
    else:
      return f"Unsupported algorithm: {algorithm_name}"
  except InvalidSignature:
    return "Cryptographic signature does not match"
  except Exception as unexpected_error:
    return f"Unexpected error during signature verification: {unexpected_error}"

  return None

